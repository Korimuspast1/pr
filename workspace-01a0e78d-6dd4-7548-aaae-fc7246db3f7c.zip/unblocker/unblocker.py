#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
unblocker — диагностика и сброс ЛОКАЛЬНЫХ ограничений доступа к сайтам (Linux).

Предназначен ТОЛЬКО для устройства, которым вы владеете и администрируете сами.
Работает напрямую с реальными системными файлами:

  * /etc/hosts               — домены, завёрнутые на 127.0.0.1 / 0.0.0.0 / ::1
  * /etc/resolv.conf         — DNS-серверы (подмена на локальный фильтр)
  * системный прокси         — переменные *_proxy, GNOME (gsettings)
  * iptables / nftables      — правила DROP / REJECT

Режим scan только показывает. Режим reset меняет реальные файлы, предварительно
делая резервные копии в /var/backups/unblocker, чтобы всё можно было откатить.

Использование:
    sudo python3 unblocker.py            # только показать, что найдено
    sudo python3 unblocker.py scan       # то же самое
    sudo python3 unblocker.py reset      # сбросить (спросит подтверждение)
    sudo python3 unblocker.py reset --yes            # без вопросов
    sudo python3 unblocker.py reset --dns 1.1.1.1    # свой публичный DNS
    sudo python3 unblocker.py restore    # откатить из последних бэкапов

Полезные флаги reset:
    --no-hosts     не трогать /etc/hosts
    --no-dns       не менять DNS
    --no-proxy     не сбрасывать прокси
    --firewall     ДОПОЛНИТЕЛЬНО сбросить правила фаервола (по умолчанию только
                   показывается, не трогается)
"""

import argparse
import datetime
import os
import platform
import shutil
import socket
import subprocess
import sys

# --- Реальные системные пути (Linux) ---
HOSTS_PATH = "/etc/hosts"
RESOLV_PATH = "/etc/resolv.conf"
BACKUP_DIR = "/var/backups/unblocker"

# Публичные резолверы по умолчанию (Cloudflare + Google).
DEFAULT_DNS = ["1.1.1.1", "8.8.8.8"]

# IP, на которые обычно "заворачивают" домены, чтобы их заблокировать.
BLOCK_TARGETS = {"127.0.0.1", "0.0.0.0", "::1"}

# Служебные имена, которые НЕЛЬЗЯ считать блокировкой (системные строки hosts).
SAFE_HOSTS_NAMES = {
    "localhost", "localhost.localdomain", "broadcasthost",
    "ip6-localhost", "ip6-loopback", "ip6-allnodes", "ip6-allrouters",
    "ip6-mcastprefix", "ip6-localnet",
}

# ---------------------------------------------------------------------------
# Вспомогательное
# ---------------------------------------------------------------------------

class C:
    R = "\033[91m"; G = "\033[92m"; Y = "\033[93m"; B = "\033[94m"
    BOLD = "\033[1m"; DIM = "\033[2m"; END = "\033[0m"


def title(text):
    print(f"\n{C.BOLD}{C.B}== {text} =={C.END}")


def ok(text):
    print(f"  {C.G}[OK]{C.END} {text}")


def warn(text):
    print(f"  {C.Y}[!]{C.END} {text}")


def info(text):
    print(f"  {C.DIM}{text}{C.END}")


def is_root():
    return os.geteuid() == 0


def run(cmd, **kw):
    """Запустить команду, вернуть (код, stdout, stderr). Никогда не бросает."""
    try:
        p = subprocess.run(cmd, capture_output=True, text=True,
                           errors="replace", timeout=30, **kw)
        return p.returncode, p.stdout or "", p.stderr or ""
    except FileNotFoundError:
        return 127, "", "not found"
    except Exception as e:  # noqa
        return 1, "", str(e)


def timestamp():
    return datetime.datetime.now().strftime("%Y%m%d-%H%M%S")


def ensure_backup_dir():
    os.makedirs(BACKUP_DIR, exist_ok=True)


def backup_file(path):
    if not os.path.exists(path):
        return None
    ensure_backup_dir()
    name = os.path.basename(path) + "." + timestamp() + ".bak"
    dest = os.path.join(BACKUP_DIR, name)
    shutil.copy2(path, dest)
    # Ссылка на "последний" бэкап для restore.
    latest = os.path.join(BACKUP_DIR, os.path.basename(path) + ".latest")
    try:
        shutil.copy2(path, latest)
    except Exception:
        pass
    return dest


# ---------------------------------------------------------------------------
# hosts
# ---------------------------------------------------------------------------

def _looks_like_domain(name):
    """Похоже ли имя на внешний домен (а не служебную запись/имя хоста)."""
    n = name.lower()
    if n in SAFE_HOSTS_NAMES:
        return False
    if "." not in n:                 # чистое имя хоста без домена
        return False
    if n.endswith(".local") or n.endswith(".localdomain"):
        return False
    return True


def parse_hosts_blocks():
    """Вернуть строки /etc/hosts, которые ЯВНО блокируют внешние домены.

    Только настоящие блокировки: домен, завёрнутый на 127.0.0.1 / 0.0.0.0 / ::1.
    Служебные строки (localhost, ip6-*, имя машины на 127.0.1.1) НЕ включаются.
    """
    blocks = []
    if not os.path.exists(HOSTS_PATH):
        return blocks
    try:
        with open(HOSTS_PATH, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
    except Exception as e:
        warn(f"не удалось прочитать {HOSTS_PATH}: {e}")
        return blocks

    for i, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        ip = parts[0]
        names = parts[1:]
        if ip not in BLOCK_TARGETS:
            continue
        if any(_looks_like_domain(n) for n in names):
            blocks.append((i, ip, names))
    return blocks


def scan_hosts():
    title("Файл hosts")
    info(HOSTS_PATH)
    blocks = parse_hosts_blocks()
    if not blocks:
        ok("блокировок доменов не найдено")
        return
    warn(f"найдено записей, блокирующих сайты: {len(blocks)}")
    for ln, ip, names in blocks[:200]:
        print(f"      строка {ln:>4}: {ip:<15} {' '.join(names)}   ({C.R}блокировка{C.END})")
    if len(blocks) > 200:
        info(f"... и ещё {len(blocks) - 200} строк")


def reset_hosts(dry=False):
    title("Сброс файла hosts")
    if not os.path.exists(HOSTS_PATH):
        warn(f"{HOSTS_PATH} отсутствует — нечего чистить")
        return
    blocks = parse_hosts_blocks()
    if not blocks:
        ok("блокировок в hosts нет, файл не меняется")
        return
    with open(HOSTS_PATH, "r", encoding="utf-8", errors="replace") as f:
        lines = f.readlines()

    remove_line_nums = {ln for ln, _ip, _n in blocks}
    kept, removed = [], []
    for i, raw in enumerate(lines, 1):
        if i in remove_line_nums:
            removed.append(raw.rstrip("\n"))
        else:
            kept.append(raw)

    print(f"  будет удалено строк: {C.R}{len(removed)}{C.END}, останется: {len(kept)}")
    for r in removed[:50]:
        print(f"      {C.DIM}- {r}{C.END}")
    if dry:
        info("(режим просмотра, файл не изменён)")
        return
    dest = backup_file(HOSTS_PATH)
    ok(f"резервная копия: {dest}")
    tmp = HOSTS_PATH + ".unblocker.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.writelines(kept)
    shutil.copymode(HOSTS_PATH, tmp)
    os.replace(tmp, HOSTS_PATH)
    ok("файл /etc/hosts очищен от блокировок")


# ---------------------------------------------------------------------------
# DNS
# ---------------------------------------------------------------------------

def _net_devices():
    devs = []
    code, out, _ = run(["ls", "/sys/class/net"])
    if code == 0:
        for d in out.split():
            if d != "lo":
                devs.append(d)
    return devs


def scan_dns():
    title("DNS")
    if os.path.islink(RESOLV_PATH):
        info(f"{RESOLV_PATH} -> {os.path.realpath(RESOLV_PATH)} "
             f"(управляется systemd-resolved / NetworkManager)")
    if os.path.exists(RESOLV_PATH):
        with open(RESOLV_PATH, "r", errors="replace") as f:
            servers = [l.split()[1] for l in f
                       if l.strip().startswith("nameserver") and len(l.split()) > 1]
        if servers:
            info("текущие серверы: " + ", ".join(servers))
            if all(s.startswith("127.") for s in servers):
                warn("DNS указывает только на localhost — возможен локальный DNS-фильтр")
            else:
                ok("DNS настроен на внешние серверы")
        else:
            warn("серверы не заданы")
    else:
        warn(f"{RESOLV_PATH} не найден")


def reset_dns(dns_servers, dry=False):
    title("Установка публичного DNS")
    print(f"  целевые серверы: {C.G}{', '.join(dns_servers)}{C.END}")
    if dry:
        info("(режим просмотра, ничего не менялось)")
        return
    # Если resolv.conf — симлинк на systemd-resolved, правка файла не поможет.
    if os.path.islink(RESOLV_PATH):
        warn("resolv.conf управляется системой (симлинк).")
        warn("Меняю через systemd-resolved, если доступен...")
        applied = False
        for dev in _net_devices():
            code, _, _ = run(["resolvectl", "dns", dev] + dns_servers)
            if code == 0:
                applied = True
        if applied:
            ok("DNS обновлён через resolvectl")
            return
        warn("resolvectl недоступен — переписываю resolv.conf напрямую")
    backup_file(RESOLV_PATH)
    with open(RESOLV_PATH, "w") as f:
        f.write("# unblocker: публичный DNS\n")
        for s in dns_servers:
            f.write(f"nameserver {s}\n")
    ok(f"{RESOLV_PATH} обновлён")
    info("Если DNS вернётся к старому — его перезаписывает NetworkManager/systemd-resolved.")


# ---------------------------------------------------------------------------
# Прокси
# ---------------------------------------------------------------------------

def scan_proxy():
    title("Прокси")
    found = False
    for var in ("http_proxy", "https_proxy", "HTTP_PROXY", "HTTPS_PROXY",
                "all_proxy", "ALL_PROXY", "ftp_proxy"):
        if os.environ.get(var):
            warn(f"переменная окружения {var}={os.environ[var]}")
            found = True
    code, out, _ = run(["gsettings", "get", "org.gnome.system.proxy", "mode"])
    if code == 0 and "none" not in out.lower():
        warn(f"прокси GNOME: mode = {out.strip()}")
        found = True
    if not found:
        ok("активных прокси не обнаружено")


def reset_proxy(dry=False):
    title("Сброс прокси")
    if dry:
        info("(режим просмотра)")
        return
    code, _, _ = run(["gsettings", "set", "org.gnome.system.proxy", "mode", "none"])
    if code == 0:
        ok("прокси GNOME отключён (если использовался)")
    else:
        info("gsettings недоступен (не GNOME) — системный прокси GNOME не трогаю")
    info("Переменные окружения *_proxy снимите вручную в ~/.bashrc, ~/.profile, "
         "/etc/environment, если они там прописаны.")


# ---------------------------------------------------------------------------
# Фаервол
# ---------------------------------------------------------------------------

def scan_firewall():
    title("Фаервол")
    seen = False
    code, out, _ = run(["nft", "list", "ruleset"])
    if code == 0 and out.strip():
        seen = True
        drops = [l for l in out.splitlines() if "drop" in l or "reject" in l]
        info("nftables активен")
        if drops:
            warn(f"правил drop/reject: {len(drops)} (могут блокировать сайты)")
            for d in drops[:20]:
                print(f"      {d.strip()}")
        else:
            ok("явных drop/reject в nftables не видно")
    code2, out2, _ = run(["iptables", "-S"])
    if code2 == 0:
        seen = True
        drops = [l for l in out2.splitlines() if "-j DROP" in l or "-j REJECT" in l]
        if drops:
            warn(f"iptables: правил DROP/REJECT: {len(drops)}")
            for d in drops[:20]:
                print(f"      {d.strip()}")
        else:
            ok("iptables: правил DROP/REJECT не найдено")
    if not seen:
        info("iptables/nftables недоступны или пусты")


def reset_firewall(dry=False):
    title("Сброс правил фаервола")
    warn("Это сбросит ПОЛЬЗОВАТЕЛЬСКИЕ правила фаервола (по умолчанию — всё разрешено).")
    if dry:
        info("(режим просмотра, ничего не менялось)")
        return
    ensure_backup_dir()
    code, out, _ = run(["iptables-save"])
    if code == 0:
        path = os.path.join(BACKUP_DIR, f"iptables.{timestamp()}.rules")
        with open(path, "w") as f:
            f.write(out)
        ok(f"текущие правила iptables сохранены: {path}")
    for chain in ("INPUT", "FORWARD", "OUTPUT"):
        run(["iptables", "-P", chain, "ACCEPT"])
    run(["iptables", "-F"])
    run(["iptables", "-X"])
    run(["nft", "flush", "ruleset"])
    ok("правила iptables/nftables сброшены")


# ---------------------------------------------------------------------------
# Проверка доступа
# ---------------------------------------------------------------------------

def connectivity_test(hosts=("example.com", "wikipedia.org", "github.com")):
    title("Проверка доступа к сайтам")
    for h in hosts:
        try:
            ip = socket.gethostbyname(h)
            s = socket.create_connection((ip, 443), timeout=5)
            s.close()
            ok(f"{h} -> {ip} : доступен")
        except socket.gaierror:
            warn(f"{h}: не резолвится (проблема DNS)")
        except Exception as e:  # noqa
            warn(f"{h}: соединение не удалось ({e})")


# ---------------------------------------------------------------------------
# restore
# ---------------------------------------------------------------------------

def restore():
    title("Восстановление из последних резервных копий")
    if not os.path.isdir(BACKUP_DIR):
        warn(f"каталог бэкапов не найден: {BACKUP_DIR}")
        return
    restored = False
    for path in (HOSTS_PATH, RESOLV_PATH):
        if os.path.islink(path):
            continue
        latest = os.path.join(BACKUP_DIR, os.path.basename(path) + ".latest")
        if os.path.exists(latest):
            shutil.copy2(latest, path)
            ok(f"{path} восстановлен из {latest}")
            restored = True
    if not restored:
        warn("свежих бэкапов hosts/resolv.conf не найдено")
    info("Правила фаервола откатываются вручную из файлов iptables.*.rules:")
    info(f"  sudo iptables-restore < {BACKUP_DIR}/iptables.<дата>.rules")


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def do_scan():
    scan_hosts()
    scan_dns()
    scan_proxy()
    scan_firewall()
    connectivity_test()
    print(f"\n{C.DIM}Это был режим просмотра. Чтобы применить сброс: "
          f"sudo python3 unblocker.py reset{C.END}")


def do_reset(args):
    print(f"{C.BOLD}Будет выполнен сброс локальных ограничений на ЭТОМ устройстве.{C.END}")
    print("Действия:")
    if not args.no_hosts:  print("  - очистка /etc/hosts от блокировок (с бэкапом)")
    if not args.no_dns:    print(f"  - установка публичного DNS: {', '.join(args.dns)}")
    if not args.no_proxy:  print("  - отключение системного прокси")
    if args.firewall:      print("  - сброс правил фаервола (с бэкапом)")
    if not args.yes:
        ans = input("\nПродолжить? [y/N]: ").strip().lower()
        if ans not in ("y", "yes", "д", "да"):
            print("Отменено.")
            return
    if not args.no_hosts:
        reset_hosts()
    if not args.no_dns:
        reset_dns(args.dns)
    if not args.no_proxy:
        reset_proxy()
    if args.firewall:
        reset_firewall()
    connectivity_test()
    print(f"\n{C.G}{C.BOLD}Готово.{C.END} Если что-то пошло не так — откат: "
          f"sudo python3 unblocker.py restore")


def build_parser():
    p = argparse.ArgumentParser(
        description="Диагностика и сброс локальных ограничений доступа к сайтам (Linux).")
    sub = p.add_subparsers(dest="cmd")

    sub.add_parser("scan", help="только показать найденные ограничения (по умолчанию)")

    r = sub.add_parser("reset", help="сбросить локальные ограничения")
    r.add_argument("--yes", "-y", action="store_true", help="не спрашивать подтверждение")
    r.add_argument("--dns", nargs="+", default=DEFAULT_DNS, help="какие DNS-серверы поставить")
    r.add_argument("--no-hosts", action="store_true")
    r.add_argument("--no-dns", action="store_true")
    r.add_argument("--no-proxy", action="store_true")
    r.add_argument("--firewall", action="store_true",
                   help="дополнительно сбросить правила фаервола")

    sub.add_parser("restore", help="откатить из последних резервных копий")
    return p


def main():
    if platform.system().lower() != "linux":
        print("Эта версия предназначена только для Linux.")
        sys.exit(1)

    print(f"{C.BOLD}unblocker{C.END} — сброс локальных ограничений доступа (Linux)")
    if not is_root():
        warn("Запущено без прав root.")
        warn("Для правки /etc/hosts, DNS и фаервола нужны права root:")
        warn("  sudo python3 unblocker.py ...")
        print()

    parser = build_parser()
    args = parser.parse_args()
    cmd = args.cmd or "scan"

    if cmd == "scan":
        do_scan()
    elif cmd == "reset":
        do_reset(args)
    elif cmd == "restore":
        restore()
    else:
        parser.print_help()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nПрервано.")
        sys.exit(130)
