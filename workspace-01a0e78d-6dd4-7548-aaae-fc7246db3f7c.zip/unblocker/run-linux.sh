#!/usr/bin/env bash
# Удобный запуск с правами root.
# Использование:  ./run-linux.sh scan   |   ./run-linux.sh reset   |   ./run-linux.sh restore
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"

# Предпочитаем собранный бинарник, иначе запускаем через python3.
if [ -x "$DIR/dist/unblocker-linux" ]; then
    exec sudo "$DIR/dist/unblocker-linux" "$@"
else
    exec sudo python3 "$DIR/unblocker.py" "$@"
fi
